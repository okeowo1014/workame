from django.contrib import admin
from django.urls import path, include

from api.views import ActivateUser, reset_password

app_name = 'worka'
urlpatterns = [
    path('admin/', admin.site.urls),
    path('', include('api.urls')),
    path('interview/', include('interview.urls')),
    path('utility/',include('utility.urls')),
    path('chat/',include('chat.urls')),
    path('activate/<str:uid>/<str:token>/', ActivateUser.as_view(),name="user-activate"),
    path('password/reset/confirm/<str:uid>/<str:token>/', reset_password, name='passwordresetpage')

]